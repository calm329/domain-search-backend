// Import required dependencies and modules  
const { getSuggestions } = require('../helpers/getSuggetion.js');  
const axios = require("axios");  

// Get GoDaddy API credentials from environment variables  
const GODADDY_API_KEY = process.env.GODADDY_API_KEY;  
const GODADDY_API_SECRET = process.env.GODADDY_API_SECRET;  

const CHUNK_SIZE = 50;  

// Helper function to split array into chunks  
const chunkArray = (array, size) => {  
    const result = [];  
    for (let i = 0; i < array.length; i += size) {  
        result.push(array.slice(i, i + size));  
    }  
    return result;  
};  

// Function to check the availability of domains using GoDaddy API  
async function checkAvailability(domains) {  
    const url = 'https://api.ote-godaddy.com/v1/domains/available?checkType=FAST'; // Use the appropriate GoDaddy API endpoint  

    const headers = {  
        Authorization: `sso-key ${GODADDY_API_KEY}:${GODADDY_API_SECRET}`,  
        'Content-Type': 'application/json',  
    };  

    const chunks = chunkArray(domains, CHUNK_SIZE);  
    let results = [];
    

    for (const chunk of chunks) {  
        const body = chunk;
        console.log(body)  
        try {  
            const response = await axios.post(url, JSON.stringify(body), { headers });  
            results = results.concat(response.data.domains);
            console.log(results)
        } catch (error) {  
            console.error('err', error);  
            throw new Error('Error communicating with GoDaddy API');  
        }  
    }  

    return results;  
}  

// Controller function for API endpoint to check a single domain  
exports.checkDomain = async (req, res) => {  
    const { domainName } = req.params;  

    try {  
        const response = await checkAvailability([{ domain: `${domainName}.com` }]);  
        const isAvailable = response[0] && response[0].available;  

        res.send({  
            domain: domainName,  
            available: isAvailable,  
        });  
    } catch (error) {  
        console.error('Error in domain check:', error);  
        res.status(500).send('Internal Server Error');  
    }  
};  

// Controller function for API endpoint to search domain suggestions and check their availability  
exports.searchSuggestions = async (req, res) => {  
    const { keyword } = req.query;  
    let suggestions;  

    const domainTerm = keyword.replace(/\s+/g, '');  
    try {  
        // Get domain name suggestions based on the keyword  
        suggestions = await getSuggestions(domainTerm);  

        // Check the availability of the suggested domain names  
        const availabilityResponse = await checkAvailability(suggestions);  

        // Filter and get only the available domain names  
        const availableSuggestions = availabilityResponse  
            .filter(result => result.available)  
            .map(result => result.domain);  

        res.json({  
            suggestions: availableSuggestions,  
        });  
    } catch (error) {  
        console.error('Error in domain search:', error);  
        res.status(500).send('Internal Server Error');  
    }  
};  

// Controller function for API endpoint to register a domain  
exports.registerDomain = async (req, res) => {  
    const { domain, user } = req.body;  
    try {  
        const registrationResult = await namecheapService.registerDomain(domain, user);  
        res.json(registrationResult);  
    } catch (error) {  
        console.error('Error in domain registration:', error);  
        res.status(500).send('Internal Server Error');  
    }  
};